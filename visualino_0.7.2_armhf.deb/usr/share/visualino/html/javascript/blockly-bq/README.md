blockly-bq
==========

This project is a first fork of the [blockly](https://developers.google.com/blockly) visual programming library for [bitbloq](http://bitbloq.bq.com) modified until October, 23th, 2014. It's not simply a directive that encapsulates the blockly library, but a modified version of the library to provide better integration with [roboblocks](https://github.com/bq/roboblocks).


