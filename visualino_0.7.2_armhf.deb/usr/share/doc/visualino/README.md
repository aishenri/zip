Visualino
=========

Visual programming environment for Arduino.


Install
-------

Check INSTALL file.


Requirements
------------

In order to Visualino to execute sketches, install Arduino IDE >= 1.6.


Configure
---------

To setup the path to the Arduino IDE command line tool in your platform
check the online documentation at [http://www.visualino.net/docs/](www.visualino.net/docs/).


Support
-------

Go to the [http://www.visualino.net/forum/](forum).


Developer
---------

Víctor R. Ruiz <rvr@linotipo.es>


Credits
-------

* [https://developers.google.com/blockly/](Google Blockly).
* [https://github.com/bq/roboblocks](bq's roboblocks).


License
-------

Check LICENSE file.

